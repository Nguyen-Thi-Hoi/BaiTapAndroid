package vn.udn.vku.nhhai.uedn4l11_sqlite

class User(var name: String = "", var birthYear: Int = 0) {
}