package com.gmail.vttphuong.lession4_exercise2a_phuong_n4ued

class CountryInfo(val name:String,val population:Double,val flag:Int) {
}