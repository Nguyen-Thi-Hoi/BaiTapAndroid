package com.gmail.vttphuong.lesson6_photoapp_phuong_n4ued

class ArticleInfo(val id: Int, val title: String, val imgURL: String, val desc: String) {
}