package com.morgan.trailers.data.models


class MovieRefreshError(message: String, cause: Throwable) : Throwable(message, cause)
